"use client"

import { useEffect, useState, useMemo } from 'react'

interface FloatingDay {
  id: number
  value: number
  x: number
  y: number
  size: number
  opacity: number
  animationDuration: number
  delay: number
  speed: number
}

interface TimelineParticle {
  id: number
  x: number
  y: number
  size: number
  opacity: number
  speed: number
  delay: number
}

export default function InteractiveBackground() {
  const [dimensions, setDimensions] = useState({ width: 0, height: 0 })
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 })

  useEffect(() => {
    const updateDimensions = () => {
      setDimensions({
        width: window.innerWidth,
        height: window.innerHeight
      })
    }

    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY })
    }

    updateDimensions()
    
    window.addEventListener('resize', updateDimensions)
    window.addEventListener('mousemove', handleMouseMove)
    
    return () => {
      window.removeEventListener('resize', updateDimensions)
      window.removeEventListener('mousemove', handleMouseMove)
    }
  }, [])

  const floatingDays = useMemo(() => {
    if (dimensions.width === 0 || dimensions.height === 0) return []
    
    const newDays: FloatingDay[] = []
    
    // Generate days 1-31 with multiple instances
    for (let i = 1; i <= 31; i++) {
      const instances = Math.floor(Math.random() * 3) + 2
      
      for (let j = 0; j < instances; j++) {
        newDays.push({
          id: i * 100 + j,
          value: i,
          x: Math.random() * dimensions.width,
          y: Math.random() * dimensions.height,
          size: Math.random() * 20 + 12,
          opacity: Math.random() * 0.15 + 0.05,
          animationDuration: Math.random() * 15 + 20,
          delay: Math.random() * 10,
          speed: Math.random() * 0.5 + 0.2
        })
      }
    }
    
    return newDays
  }, [dimensions])

  const timelineParticles = useMemo(() => {
    if (dimensions.width === 0 || dimensions.height === 0) return []
    
    const particles: TimelineParticle[] = []
    const particleCount = Math.floor(dimensions.width / 100)
    
    for (let i = 0; i < particleCount; i++) {
      particles.push({
        id: i,
        x: (i / particleCount) * dimensions.width,
        y: dimensions.height * 0.3 + Math.random() * dimensions.height * 0.4,
        size: Math.random() * 3 + 1,
        opacity: Math.random() * 0.3 + 0.1,
        speed: Math.random() * 2 + 1,
        delay: Math.random() * 5
      })
    }
    
    return particles
  }, [dimensions])

  if (dimensions.width === 0) return null

  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
      {/* Dark gradient background */}
      <div className="absolute inset-0 bg-gradient-to-br from-gray-900 via-blue-900/20 to-purple-900/20" />
      
      {/* Timeline lines */}
      <svg className="absolute inset-0 w-full h-full">
        <defs>
          <linearGradient id="timelineGradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#3B82F6" stopOpacity="0.1" />
            <stop offset="50%" stopColor="#8B5CF6" stopOpacity="0.2" />
            <stop offset="100%" stopColor="#3B82F6" stopOpacity="0.1" />
          </linearGradient>
        </defs>
        
        {/* Horizontal timeline lines */}
        {[0.2, 0.5, 0.8].map((position, index) => (
          <line
            key={`h-line-${index}`}
            x1="0"
            y1={dimensions.height * position}
            x2={dimensions.width}
            y2={dimensions.height * position}
            stroke="url(#timelineGradient)"
            strokeWidth="1"
            opacity="0.3"
          />
        ))}
        
        {/* Vertical timeline lines */}
        {[0.25, 0.5, 0.75].map((position, index) => (
          <line
            key={`v-line-${index}`}
            x1={dimensions.width * position}
            y1="0"
            x2={dimensions.width * position}
            y2={dimensions.height}
            stroke="url(#timelineGradient)"
            strokeWidth="1"
            opacity="0.2"
          />
        ))}
      </svg>
      
      {/* Timeline particles */}
      {timelineParticles.map((particle) => (
        <div
          key={particle.id}
          className="absolute rounded-full bg-purple-400"
          style={{
            left: `${particle.x}px`,
            top: `${particle.y}px`,
            width: `${particle.size}px`,
            height: `${particle.size}px`,
            opacity: particle.opacity,
            animation: `moveTimeline ${particle.speed}s linear ${particle.delay}s infinite`,
            boxShadow: `0 0 ${particle.size * 2}px rgba(168, 85, 247, 0.5)`
          }}
        />
      ))}
      
      {/* Floating day numbers */}
      {floatingDays.map((day) => (
        <div
          key={day.id}
          className="absolute font-bold select-none transition-all duration-1000 ease-out"
          style={{
            left: `${day.x}px`,
            top: `${day.y}px`,
            fontSize: `${day.size}px`,
            opacity: day.opacity,
            fontFamily: 'var(--font-sans)',
            animation: `floatDay ${day.animationDuration}s ease-in-out ${day.delay}s infinite`,
            color: `rgba(148, 163, 184, ${day.opacity * 2})`,
            textShadow: `0 0 10px rgba(148, 163, 184, 0.3)`,
            transform: `translateZ(0)`,
            willChange: 'transform, opacity',
            backfaceVisibility: 'hidden'
          }}
        >
          {day.value}
        </div>
      ))}
      
      {/* Mouse follower effect */}
      <div
        className="absolute rounded-full pointer-events-none"
        style={{
          left: `${mousePosition.x}px`,
          top: `${mousePosition.y}px`,
          width: '200px',
          height: '200px',
          background: 'radial-gradient(circle, rgba(59, 130, 246, 0.1) 0%, transparent 70%)',
          transform: 'translate(-50%, -50%)',
          transition: 'opacity 0.3s ease-out',
          opacity: 0.8
        }}
      />
      
      <style jsx>{`
        @keyframes floatDay {
          0% {
            opacity: 0.05;
            transform: translateY(0px) translateX(0px) scale(1) rotate(0deg) translateZ(0);
          }
          20% {
            opacity: 0.15;
            transform: translateY(-20px) translateX(10px) scale(1.05) rotate(1deg) translateZ(0);
          }
          40% {
            opacity: 0.1;
            transform: translateY(-40px) translateX(-10px) scale(0.95) rotate(-1deg) translateZ(0);
          }
          60% {
            opacity: 0.2;
            transform: translateY(-25px) translateX(5px) scale(1.02) rotate(0.5deg) translateZ(0);
          }
          80% {
            opacity: 0.08;
            transform: translateY(-10px) translateX(3px) scale(1.01) rotate(0deg) translateZ(0);
          }
          100% {
            opacity: 0.05;
            transform: translateY(0px) translateX(0px) scale(1) rotate(0deg) translateZ(0);
          }
        }
        
        @keyframes moveTimeline {
          0% {
            transform: translateX(0px) translateY(0px);
            opacity: 0;
          }
          10% {
            opacity: 0.3;
          }
          90% {
            opacity: 0.3;
          }
          100% {
            transform: translateX(${dimensions.width}px) translateY(0px);
            opacity: 0;
          }
        }
        
        @media (prefers-reduced-motion: reduce) {
          @keyframes floatDay {
            0%, 100% {
              opacity: 0.1;
              transform: translateY(0px) translateX(0px) scale(1) rotate(0deg) translateZ(0);
            }
          }
          
          @keyframes moveTimeline {
            0%, 100% {
              transform: translateX(0px) translateY(0px);
              opacity: 0.2;
            }
          }
        }
      `}</style>
    </div>
  )
}
