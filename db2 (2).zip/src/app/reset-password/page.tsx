import ResetPasswordPage from '@/components/reset-password-page'

export default function ResetPassword() {
  return <ResetPasswordPage />
}
