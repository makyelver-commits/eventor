import ForgotPasswordPage from '@/components/forgot-password-page'

export default function ForgotPassword() {
  return <ForgotPasswordPage />
}
