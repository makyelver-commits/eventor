import AuthPage from '@/components/auth-page'

export default function Auth() {
  return <AuthPage />
}
